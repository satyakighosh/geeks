import React from "react";
import GeekButton from "./GeekButton"

export default function SimpleState() {
    const [count, setCount] = React.useState<number>(0);
    return <GeekButton name="count" label={count.toString()} onClick={() => setCount(count + 1)} />
}