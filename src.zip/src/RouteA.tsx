
import { useParams } from "react-router-dom"

export default function RouteA() {
    const params = useParams<{name: string}>();
    return <div>{"hello " + params.name}</div>
}