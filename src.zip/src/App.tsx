import React from "react";
import ReactDOM from "react-dom";
import { Routes } from 'react-router';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import './App.css';
import GeekButton from './GeekButton';
import RouteA from './RouteA';
import SimpleState from './SimpleState';

/*
url1 --> component1
url2 --> component2

Step1: Surround app with browser router
Step2: All our routes are present in App
*/
export default function App() {
  return (
    <>
      {/* <GeekButton name="name" label='label' onClick={() => alert('fuckyou')}/> 
      <SimpleState/> */}
      <BrowserRouter>
        <Routes>
          <Route path="/SimpleState" element={<SimpleState />} />
          <Route path="/RouteA/:name" element={<RouteA />} />
          <Route path="/SubmitButton"
            element={() => <GeekButton name="submitName" label='submit' onClick={() => alert('submit button is invoked')} />} />
          <Route path="/ResetButton"
            element={() => <GeekButton name="resetName" label='reset' onClick={() => alert('reset button is invoked')} />} />
        </Routes>
      </BrowserRouter>

      {/* passing function as argument to the prop: onclick() */}
      {/* <GeekButton name="resetName" label='reset' onClick={() => alert('reset button is invoked')} /> */}
    </>
  );
}

// ReactDOM.render(
//   <BrowserRouter>
//     <App />
//   </BrowserRouter>,
//   document.getElementById("root")
// );
